import Constants from 'expo-constants';
import { StyleSheet, View } from 'react-native';

import Balance from '../components/Balance';
import Card from '../components/Card';
import Transactions from '../components/Transactions';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.staticSection}>
        <Card />
        <Balance />
      </View>
      <Transactions />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    gap: 16,
    paddingTop: 16 + Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    overflowX: 'hidden',
  },
  staticSection: {
    paddingHorizontal: 16,
  },
});
